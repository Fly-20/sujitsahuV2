---
widget: featurette
headless: true
weight: 20
title: Features
subtitle: ✨ Teach _anything_ with
feature:
  - icon: chalkboard-teacher
    icon_pack: fas
    name: Slides
    description:
  - icon: video
    icon_pack: fas
    name: Video
    description:
  - icon: code
    icon_pack: fas
    name: Math & Code
    description:
---
