---
widget: portfolio
headless: true
weight: 30
title: Explore top courses
subtitle:
content:
  filters:
    folders:
      - course
    kinds:
      - section
    exclude_tags:
      - preface

  filter_default: 0

  filter_button:
    - name: All Courses
      tag: '*'
    - name: Previous
      tag: previous
    - name: Current
      tag: current
design:
  columns: '1'
  view: masonry
  flip_alt_rows: false
---
